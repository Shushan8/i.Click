package com.example.i_click

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
